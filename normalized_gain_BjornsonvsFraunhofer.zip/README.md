# Book-Chapter-on-ELAA
This repository contains the code for the book chapter "Near-Field Beamforming and Multiplexing Using Extremely Large Aperture Arrays"
